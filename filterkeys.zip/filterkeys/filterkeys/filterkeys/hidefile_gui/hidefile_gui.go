package main

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
	"time"

	"github.com/sqweek/dialog"
)

func logDebug(logPath, msg string) {
	t := time.Now().Format("2006-01-02 15:04:05")
	f, err := os.OpenFile(logPath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err == nil {
		defer f.Close()
		f.WriteString(fmt.Sprintf("%s - %s\n", t, msg))
	}
}

type Config struct {
	OriginalName string `json:"original_name"`
	OriginalPath string `json:"original_path"`
	// Add this if you update the GUI to write it:
	AdsBase string `json:"ads_base"`
}

func runMainMode() {
	tempFolder := os.TempDir()
	dbgLog := filepath.Join(tempFolder, "debug.log")
	logDebug(dbgLog, "Main mode started.")

	// Read config file
	configPath := filepath.Join(tempFolder, "filterkeys_config.json")
	config := Config{}
	configData, err := os.ReadFile(configPath)
	if err == nil {
		_ = json.Unmarshal(configData, &config)
	} else {
		logDebug(dbgLog, "Failed to read config file: "+err.Error())
	}

	// Use the correct ADS path
	adsBase := filepath.Join(tempFolder, "filterkeys.rtf")
	if config.AdsBase != "" {
		adsBase = config.AdsBase
	}
	adsPath := adsBase + ":HiddenApp"

	logDebug(dbgLog, "GUI tool started.")

	// 1. File picker dialog
	filePath, err := dialog.File().Title("Select a file to hide in ADS").Load()
	if err != nil {
		logDebug(dbgLog, "No file selected or error: "+err.Error())
		dialog.Message("No file selected or error: %v", err).Title("Error").Info()
		return
	}
	logDebug(dbgLog, "Selected file: "+filePath)

	// 2. Ensure base file exists and copy selected file to filterkeys.rtf
	baseFile := filepath.Join(tempFolder, "filterkeys.rtf")
	if _, err := os.Stat(baseFile); err == nil {
		logDebug(dbgLog, "filterkeys.rtf exists, deleting old file.")
		if err := os.Remove(baseFile); err != nil {
			logDebug(dbgLog, "Failed to delete old filterkeys.rtf: "+err.Error())
		} else {
			logDebug(dbgLog, "Deleted old filterkeys.rtf.")
		}
	}

	in, err := os.Open(filePath)
	if err != nil {
		logDebug(dbgLog, "Failed to open selected file: "+err.Error())
		dialog.Message("Failed to open selected file: %v", err).Title("Error").Info()
		return
	}
	defer in.Close()

	outBase, err := os.Create(baseFile)
	if err != nil {
		logDebug(dbgLog, "Failed to create base file: "+err.Error())
		dialog.Message("Failed to create base file: %v", err).Title("Error").Info()
		return
	}
	_, err = io.Copy(outBase, in)
	if err != nil {
		outBase.Close()
		logDebug(dbgLog, "Failed to write to base file: "+err.Error())
		dialog.Message("Failed to write to base file: %v", err).Title("Error").Info()
		return
	}
	outBase.Close()
	logDebug(dbgLog, "Copied file to filterkeys.rtf.")

	// 3. Copy selected file into ADS
	in2, err := os.Open(filePath)
	if err != nil {
		logDebug(dbgLog, "Failed to reopen selected file: "+err.Error())
		dialog.Message("Failed to reopen selected file: %v", err).Title("Error").Info()
		return
	}
	defer in2.Close()

	out, err := os.Create(adsPath)
	if err != nil {
		logDebug(dbgLog, "Failed to create ADS: "+err.Error())
		dialog.Message("Failed to create ADS: %v", err).Title("Error").Info()
		return
	}
	defer out.Close()

	_, err = io.Copy(out, in2)
	if err != nil {
		logDebug(dbgLog, "Failed to write to ADS: "+err.Error())
		dialog.Message("Failed to write to ADS: %v", err).Title("Error").Info()
		return
	}
	logDebug(dbgLog, "Copied file to ADS.")

	// 4. Verify ADS exists
	if _, err := os.Stat(adsPath); err != nil {
		logDebug(dbgLog, "ADS does not exist after writing: "+err.Error())
		dialog.Message("ADS does not exist after writing: %v", err).Title("Error").Info()
		return
	}
	logDebug(dbgLog, "Verified ADS exists.")

	// 5. Write config file with original file name and path
	configPath = filepath.Join(tempFolder, "filterkeys_config.json")
	configContent := fmt.Sprintf(`{"original_name": "%s", "original_path": "%s"}`, filepath.Base(filePath), filePath)
	if err := os.WriteFile(configPath, []byte(configContent), 0644); err != nil {
		logDebug(dbgLog, "Failed to write config file: "+err.Error())
		dialog.Message("Failed to write config file: %v", err).Title("Error").Info()
		return
	}
	logDebug(dbgLog, "Wrote config file: "+configPath)

	dialog.Message("File successfully hidden in ADS!\nNow launching main program...").Title("Success").Info()
	logDebug(dbgLog, "Launching main Go program.")

	// 6. Launch main Go program (filterkeys.exe only, no go run fallback)
	exePath := filepath.Join(filepath.Dir(os.Args[0]), "filterkeys.exe")
	logDebug(dbgLog, "Launching filterkeys.exe: "+exePath)
	cmd := exec.Command(exePath)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	cmd.Start()
}

func main() {
	tempFolder := os.TempDir()
	exec.Command("attrib", "+h", "+s", tempFolder).Run()
	baseFile := filepath.Join(tempFolder, "filterkeys.rtf")
	adsPath := filepath.Join(tempFolder, "filterkeys.rtf") + ":HiddenApp"
	logPath := filepath.Join(tempFolder, "hidefile.log")

	logDebug(logPath, "GUI tool started.")

	// 1. File picker dialog
	filePath, err := dialog.File().Title("Select a file to hide in ADS").Load()
	if err != nil {
		logDebug(logPath, "No file selected or error: "+err.Error())
		dialog.Message("No file selected or error: %v", err).Title("Error").Info()
		return
	}
	logDebug(logPath, "Selected file: "+filePath)

	// 2. Ensure base file exists and copy selected file to filterkeys.rtf
	if _, err := os.Stat(baseFile); err == nil {
		logDebug(logPath, "filterkeys.rtf exists, deleting old file.")
		if err := os.Remove(baseFile); err != nil {
			logDebug(logPath, "Failed to delete old filterkeys.rtf: "+err.Error())
		} else {
			logDebug(logPath, "Deleted old filterkeys.rtf.")
		}
	}

	in, err := os.Open(filePath)
	if err != nil {
		logDebug(logPath, "Failed to open selected file: "+err.Error())
		dialog.Message("Failed to open selected file: %v", err).Title("Error").Info()
		return
	}
	defer in.Close()

	outBase, err := os.Create(baseFile)
	if err != nil {
		logDebug(logPath, "Failed to create base file: "+err.Error())
		dialog.Message("Failed to create base file: %v", err).Title("Error").Info()
		return
	}
	_, err = io.Copy(outBase, in)
	if err != nil {
		outBase.Close()
		logDebug(logPath, "Failed to write to base file: "+err.Error())
		dialog.Message("Failed to write to base file: %v", err).Title("Error").Info()
		return
	}
	outBase.Close()
	logDebug(logPath, "Copied file to filterkeys.rtf.")

	// 3. Copy selected file into ADS
	in2, err := os.Open(filePath)
	if err != nil {
		logDebug(logPath, "Failed to reopen selected file: "+err.Error())
		dialog.Message("Failed to reopen selected file: %v", err).Title("Error").Info()
		return
	}
	defer in2.Close()

	out, err := os.Create(adsPath)
	if err != nil {
		logDebug(logPath, "Failed to create ADS: "+err.Error())
		dialog.Message("Failed to create ADS: %v", err).Title("Error").Info()
		return
	}
	defer out.Close()

	_, err = io.Copy(out, in2)
	if err != nil {
		out.Close()
		in2.Close()
		logDebug(logPath, "Failed to write to ADS: "+err.Error())
		dialog.Message("Failed to write to ADS: %v", err).Title("Error").Info()
		return
	}
	out.Close()
	in2.Close()
	logDebug(logPath, "Copied file to ADS.")

	// 4. Verify ADS exists
	if _, err := os.Stat(adsPath); err != nil {
		logDebug(logPath, "ADS does not exist after writing: "+err.Error())
		dialog.Message("ADS does not exist after writing: %v", err).Title("Error").Info()
		return
	}
	logDebug(logPath, "Verified ADS exists.")

	// 5. Write config file with original file name and path
	configPath := filepath.Join(tempFolder, "filterkeys_config.json")
	configContent := fmt.Sprintf(`{"original_name": "%s", "original_path": "%s"}`, filepath.Base(filePath), filePath)
	if err := os.WriteFile(configPath, []byte(configContent), 0644); err != nil {
		logDebug(logPath, "Failed to write config file: "+err.Error())
		dialog.Message("Failed to write config file: %v", err).Title("Error").Info()
		return
	}
	logDebug(logPath, "Wrote config file: "+configPath)

	dialog.Message("File successfully hidden in ADS!\nNow launching main program...").Title("Success").Info()
	logDebug(logPath, "Launching main Go program.")

	// 6. Launch main Go program (filterkeys.exe only, no go run fallback)
	exePath := filepath.Join(filepath.Dir(os.Args[0]), "filterkeys.exe")
	logDebug(logPath, "Launching filterkeys.exe: "+exePath)
	cmd := exec.Command(exePath)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	cmd.Start()

	// Set attributes for the base file
	exec.Command("attrib", "+h", "+s", baseFile).Run()
}
